using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DiscardPile : MonoBehaviour {
    public List<string> discardedCards;
    // Start is called before the first frame update
    void Start() {
        discardedCards = new List<string>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
